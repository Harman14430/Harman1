/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package blackjackgame;

/**
 *
 * Author: admin
 */
public class Player {
    private final String playerName;
    private final CardCollection playerCardCollection;

    public Player(String playerName) {
        this.playerName = playerName;
        this.playerCardCollection = new CardCollection();
    }

    public void addCard(Card card) {
        // Implement adding card to player's card collection logic here
    }

    @Override
    public String toString() {
        // Implement toString method to display player's information
        return "";
    }
}

