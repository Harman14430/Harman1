package blackjackgame;

/**
 *
 * Author: admin
 */
public class Player {
    private final String playerName;
    private final CardCollection playerCardCollection;

    public Player(String playerName) {
        this.playerName = playerName;
        this.playerCardCollection = new CardCollection();
    }

    public void addCard(Card card) {
        playerCardCollection.addCardToCollection(card);
    }

    public int getTotalValue() {
        return playerCardCollection.getTotalValue();
    }

    public String getPlayerName() {
        return playerName;
    }

    @Override
    public String toString() {
        return playerName + "'s hand: " + playerCardCollection.toString();
    }
}
