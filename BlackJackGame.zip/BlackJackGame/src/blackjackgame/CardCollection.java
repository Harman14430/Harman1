package blackjackgame;

/**
 *
 * @author admin
 */
import java.util.ArrayList;
import java.util.List;

public class CardCollection {
    private final List<Card> cards;
    private int totalValue;
    private int aceCount;

    public CardCollection() {
        cards = new ArrayList<>();
        totalValue = 0;
        aceCount = 0;
    }

    public void addCardToCollection(Card card) {
        cards.add(card);
        int cardValue = calculateCardValue(card);
        totalValue += cardValue;
        if (cardValue == 11) {
            aceCount++;
        }
        adjustForAce();
    }

    private int calculateCardValue(Card card) {
        String rank = card.getRankType();
        if (rank.equals("A")) {
            return 11;
        } else if (rank.equals("K") || rank.equals("Q") || rank.equals("J")) {
            return 10;
        } else {
            return Integer.parseInt(rank);
        }
    }

    private void adjustForAce() {
        while (totalValue > 21 && aceCount > 0) {
            totalValue -= 10;
            aceCount--;
        }
    }

    public int getTotalValue() {
        return totalValue;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        for (Card card : cards) {
            sb.append(card).append(", ");
        }
        sb.append("Total value: ").append(totalValue);
        return sb.toString();
    }
}
