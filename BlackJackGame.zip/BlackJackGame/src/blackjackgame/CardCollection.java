/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package blackjackgame;

/**
 *
 * @author admin
 */
import java.util.ArrayList;
import java.util.List;

public class CardCollection {
    private final List<Card> cards;
    private int totalValue;
    private int aceCount;

    public CardCollection() {
        cards = new ArrayList<>();
        totalValue = 0;
        aceCount = 0;
    }

    public void addCardToCollection(Card card) {
        // Implement logic to add a card to the collection
    }

    private int calculateCardValue(Card card) {
        // Implement logic to calculate the value of a card
        return 0; // Placeholder
    }

    private void adjustForAce() {
        // Implement logic to adjust for Aces
    }

    public int getTotalValue() {
        return totalValue;
    }

    @Override
    public String toString() {
        // Implement toString to display the card collection
        return ""; // Placeholder
    }
}

