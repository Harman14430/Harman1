package blackjackgame;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class BlackJack {
    private final List<Player> playerList;
    private final Player dealer;
    private final Deck gameDeck;
    private int roundCounter;
    private final Scanner scanner;

    public BlackJack(List<Player> playerList) {
        this.playerList = playerList;
        this.dealer = new Player("Dealer");
        this.gameDeck = new Deck();
        this.gameDeck.shuffleDeck();
        this.roundCounter = 0;
        this.scanner = new Scanner(System.in);
    }

    public void initialDeal() {
        for (Player player : playerList) {
            player.addCard(gameDeck.dealOneCard());
            player.addCard(gameDeck.dealOneCard());
        }
        dealer.addCard(gameDeck.dealOneCard());
        dealer.addCard(gameDeck.dealOneCard());
    }

    public void playRound() {
        for (Player player : playerList) {
            boolean continuePlaying = true;
            while (continuePlaying && player.getTotalValue() < 21) {
                System.out.println(player);
                System.out.println(player.getPlayerName() + ", do you want to 'hit' or 'stand'?");
                String decision = scanner.nextLine().toLowerCase();

                if (decision.equals("hit")) {
                    player.addCard(gameDeck.dealOneCard());
                } else if (decision.equals("stand")) {
                    continuePlaying = false;
                } else {
                    System.out.println("Invalid input. Please enter 'hit' or 'stand'.");
                }
            }
        }

        // Dealer logic
        while (dealer.getTotalValue() < 17) {
            dealer.addCard(gameDeck.dealOneCard());
        }

        roundCounter++;
    }

    public void displayFinalHands() {
        System.out.println("\nFinal hands after playing round:");
        for (Player player : playerList) {
            System.out.println(player);
        }
        System.out.println(dealer);
    }

    public void displayResults() {
        for (Player player : playerList) {
            int playerTotal = player.getTotalValue();
            int dealerTotal = dealer.getTotalValue();
            System.out.println(player.getPlayerName() + "'s total: " + playerTotal);
            if (playerTotal > 21) {
                System.out.println(player.getPlayerName() + " busts! Dealer wins.");
            } else if (dealerTotal > 21 || playerTotal > dealerTotal) {
                System.out.println(player.getPlayerName() + " wins!");
            } else if (playerTotal < dealerTotal) {
                System.out.println(player.getPlayerName() + " loses! Dealer wins.");
            } else {
                System.out.println(player.getPlayerName() + " ties with the dealer.");
            }
        }
    }

    public static void main(String[] args) {
        List<Player> players = new ArrayList<>();
        players.add(new Player("Alice"));
        players.add(new Player("Bob"));

        BlackJack game = new BlackJack(players);
        game.initialDeal();

        System.out.println("Initial hands:");
        for (Player player : players) {
            System.out.println(player);
        }
        System.out.println(game.dealer);

        game.playRound();
        game.displayFinalHands();
        game.displayResults();
    }
}
