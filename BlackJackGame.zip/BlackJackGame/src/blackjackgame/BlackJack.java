

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package blackjackgame;

import java.util.ArrayList;
import java.util.List;

public class BlackJack {
    private final List<Player> playerList;
    private final Deck gameDeck;
    private int roundCounter;

    public BlackJack(List<Player> playerList) {
        this.playerList = playerList;
        this.gameDeck = new Deck();
        this.gameDeck.shuffleDeck();
        this.roundCounter = 0;
    }

    public void initialDeal() {
        // Implement initial dealing logic here
    }

    public void playRound() {
        // Implement logic for playing a round of Blackjack
    }

    public static void main(String[] args) {
        // Implement main method for testing
    }
}