/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package blackjackgame;

/**
 *
 * @author admin
 */
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Deck {
    private final List<Card> cardList;

    public Deck() {
        cardList = new ArrayList<>();
        initializeDeck();
    }

    private void initializeDeck() {
        // Implement card creation here
    }

    public void shuffleDeck() {
        // Implement shuffling logic here
    }

    public Card dealOneCard() {
        // Implement dealing logic here
        return null; // Placeholder
    }
}

