package blackjackgame;

/**
 *
 * @author admin
 */
public class Card {
    private final String suitType;
    private final String rankType;

    public Card(String suitType, String rankType) {
        this.suitType = suitType;
        this.rankType = rankType;
    }

    public String getRankType() {
        return rankType;
    }

    @Override
    public String toString() {
        return rankType + " of " + suitType;
    }
}
